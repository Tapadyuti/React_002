import React from "react";



function GreetFunctionalNormalComponent (){
    return (
        <div>
            <h5>THis is Functional Component with ES5 function.</h5>
        </div>
    )
}

export default GreetFunctionalNormalComponent;