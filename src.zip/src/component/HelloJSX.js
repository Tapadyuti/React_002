import React from 'react';


const HelloJSX = () =>{
    return React.createElement('div',null, React.createElement('h1',null, 'Hello RS'))
}
export default HelloJSX;