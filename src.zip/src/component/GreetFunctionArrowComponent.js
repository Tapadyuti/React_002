import React from "react";

export const GreetFunctionArrowComponent = () => <h5>This is Functional component with ES6 Arrow function.</h5>

//export default GreetFunctionArrowComponent; // if there is not explicite export default the have to import the exact component name with binded in {}