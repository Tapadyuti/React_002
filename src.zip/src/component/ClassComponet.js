import React, {Component} from 'react';

class ClassComponent extends Component{
    render(){
        return <h5>This is Statefull Class Component.</h5>
    }
}

export default ClassComponent;